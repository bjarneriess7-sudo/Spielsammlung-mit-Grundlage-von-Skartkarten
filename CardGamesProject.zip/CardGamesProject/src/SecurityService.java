package src;
/**
 * Verwaltet Login-Status und Zugriffskontrolle.
 */
public class SecurityService {

    private UserAccount currentLoggedInUser;

    public SecurityService() {
        this.currentLoggedInUser = null;
    }

    public boolean login(UserAccount account, String plainPassword) {
        if (account != null && account.verifyPassword(plainPassword)) {
            this.currentLoggedInUser = account;
            return true;
        }
        return false;
    }

    public void logout() {
        this.currentLoggedInUser = null;
    }

    public boolean isAuthenticated() {
        return this.currentLoggedInUser != null;
    }

    public UserAccount getCurrentUser() {
        if (!isAuthenticated()) {
            throw new IllegalStateException("Zugriff verweigert: Kein Nutzer angemeldet.");
        }
        return currentLoggedInUser;
    }
}
