package src;
import java.util.Comparator;

/**
 * Sammlung polymorpher Sortierstrategien für Spielkarten.
 */
public final class CardComparators {

    private CardComparators() {}

    public static final Comparator<Card> BY_SUIT_THEN_RANK = new Comparator<Card>() {
        @Override
        public int compare(Card c1, Card c2) {
            int suitComp = Integer.compare(c1.getSuit().ordinal(), c2.getSuit().ordinal());
            if (suitComp != 0) return suitComp;
            return Integer.compare(c1.getRank().ordinal(), c2.getRank().ordinal());
        }
    };

    public static final Comparator<Card> BY_RANK_DESCENDING = new Comparator<Card>() {
        @Override
        public int compare(Card c1, Card c2) {
            return Integer.compare(c2.getRank().ordinal(), c1.getRank().ordinal());
        }
    };
}

