package src;
/**
 * Ausnahme bei ungültigen Kartenzuweisungen oder unzulässigen Interaktionen mit Kartenobjekten.
 */
public class InvalidCardException extends RuntimeException {

    public InvalidCardException() {
        super("Operation fehlgeschlagen: Das angegebene Kartenobjekt ist ungültig oder nicht vorhanden.");
    }

    public InvalidCardException(String message) {
        super(message);
    }
}
