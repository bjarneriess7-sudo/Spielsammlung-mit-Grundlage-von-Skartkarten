package src;
/**
 * Ausnahme für unzulässige Zieh-Aktionen auf einem vollständig aufgebrauchten Kartendeck.
 */
public class EmptyDeckException extends Exception {

    public EmptyDeckException() {
        super("Operation fehlgeschlagen: Das Kartendeck enthält keine verbleibenden Karten.");
    }

    public EmptyDeckException(String message) {
        super(message);
    }
}
