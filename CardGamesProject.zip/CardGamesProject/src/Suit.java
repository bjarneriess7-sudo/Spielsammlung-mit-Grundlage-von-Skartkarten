package src;

/**
 * Das Enum Suit repräsentiert die vier klassischen Spielfarben eines Kartendecks.
 * 
 * Es kapselt sowohl den deutschen Namen als auch das entsprechende Unicode-Symbol,
 * um eine saubere und intuitive Darstellung in der Konsole zu gewährleisten.
 **/
public enum Suit {
    KREUZ("Kreuz", "♣"),
    PIK("Pik", "♠"),
    HERZ("Herz", "♥"),
    KARO("Karo", "♦");

    private final String name;
    private final String symbol;

    /**
     * Konstruktor zur Initialisierung einer Kartenfarbe.
     * 
     * @param name   Der lesbare Name der Farbe.
     * @param symbol Das grafische Symbol für die Konsolenausgabe.
     */
    Suit(String name, String symbol) {
        this.name = name;
        this.symbol = symbol;
    }

    /**
     * Gibt den Namen der Farbe zurück.
     * 
     * @return Name als String.
     */
    public String getName() {
        return name;
    }

    /**
     * Gibt das Symbol der Farbe zurück.
     * 
     * @return Symbol als String.
     */
    public String getSymbol() {
        return symbol;
    }

    @Override
    public String toString() {
        return symbol + " (" + name + ")";
    }
}