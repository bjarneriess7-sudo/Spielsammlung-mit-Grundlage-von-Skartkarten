package src;
/**
 * Repräsentiert eine Aktion innerhalb eines Spiels.
 */
interface Move {
    String getDescription();
    boolean isValid();
}

/**
 * Abstraktion eines Teilnehmers.
 */
interface Player {
    String getName();
    Hand getHand();
    int getScore();
    void addScore(int points);
    boolean isHuman();
}

/**
 * Zentrales Interface für alle spielbaren Kartenspiele.
 */
public interface GameCoreInterfaces {
    void start();
    void processTurn();
    boolean isGameOver();
    String getResultSummary();
}

