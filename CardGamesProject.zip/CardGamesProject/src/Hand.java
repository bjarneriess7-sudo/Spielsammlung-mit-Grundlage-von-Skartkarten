package src;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * Modelliert die Kartenhand eines Spielers oder Dealers.
 */
public class Hand {

    private final List<Card> cards;

    public Hand() {
        this.cards = new ArrayList<>();
    }

    public void addCard(Card card) {
        if (card == null) {
            throw new InvalidCardException("Eine Null-Karte kann nicht aufgenommen werden.");
        }
        this.cards.add(card);
    }

    public boolean removeCard(Card card) {
        return this.cards.remove(card);
    }

    public Card removeCard(int index) {
        return this.cards.remove(index);
    }

    public Card getCard(int index) {
        return this.cards.get(index);
    }

    public int calculateDefaultValue() {
        int sum = 0;
        for (Card card : this.cards) {
            sum += card.getRank().getDefaultValue();
        }
        return sum;
    }

    public int calculateBlackjackValue() {
        int total = 0;
        int aceCount = 0;
        for (Card card : this.cards) {
            if (card.getRank() == Rank.ASS) {
                aceCount++;
                total += 11;
            } else {
                total += card.getRank().getDefaultValue();
            }
        }
        while (total > 21 && aceCount > 0) {
            total -= 10;
            aceCount--;
        }
        return total;
    }

    public boolean hasRank(Rank rank) {
        for (Card card : this.cards) {
            if (card.getRank() == rank) return true;
        }
        return false;
    }

    public boolean hasSuit(Suit suit) {
        for (Card card : this.cards) {
            if (card.getSuit() == suit) return true;
        }
        return false;
    }

    public List<Card> findCardsBySuit(Suit suit) {
        List<Card> matching = new ArrayList<>();
        for (Card card : this.cards) {
            if (card.getSuit() == suit) matching.add(card);
        }
        return matching;
    }

    public void sortByRank() {
        Collections.sort(this.cards);
    }

    public void sortWithComparator(Comparator<Card> comparator) {
        if (comparator != null) {
            this.cards.sort(comparator);
        }
    }

    public void clear() {
        this.cards.clear();
    }

    public int size() {
        return this.cards.size();
    }

    public boolean isEmpty() {
        return this.cards.isEmpty();
    }

    public List<Card> getCards() {
        return Collections.unmodifiableList(this.cards);
    }

    @Override
    public String toString() {
        if (this.cards.isEmpty()) return "[Leere Hand]";
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < this.cards.size(); i++) {
            sb.append(this.cards.get(i));
            if (i < this.cards.size() - 1) sb.append(" | ");
        }
        sb.append("]");
        return sb.toString();
    }
}
