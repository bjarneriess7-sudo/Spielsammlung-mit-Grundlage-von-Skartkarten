package src;
import java.util.List;
import java.util.Random;

/**
 * Verifikations-Suite zur Überprüfung aller Basisfunktionen von Person 1.
 */
public class CoreTestRunner {

    private static int testsPassed = 0;
    private static int testsFailed = 0;

    public static void main(String[] args) {
        System.out.println("================================================================================");
        System.out.println("          AKADEMISCHE TEST-SUITE: CORE-ARCHITEKTUR & DATENMODELLE               ");
        System.out.println("================================================================================");

        test01_SuitEnumProperties();
        test02_RankEnumProperties();
        test03_CardImmutabilityAndEquality();
        test04_CardNullProtection();
        test05_DeckInitialization52Cards();
        test06_DeckInitializationSkat32Cards();
        test07_FisherYatesShuffleIntegrity();
        test08_DeckCutMechanism();
        test09_DeckDrawSingleAndEmptyException();
        test10_DeckDrawMultipleCards();
        test11_DeckDealHandsEqually();
        test12_HandNaturalSorting();
        test13_HandCustomComparatorSorting();
        test14_HandBlackjackDynamicAceCalculation();
        test15_HandFilterAndSearchMethods();

        System.out.println("================================================================================");
        System.out.println("                     ABSCHLUSSBERICHT DER TEST-SUITE                            ");
        System.out.println("================================================================================");
        System.out.println("Erfolgreiche Tests: " + testsPassed);
        System.out.println("Fehlgeschlagene Tests: " + testsFailed);

        if (testsFailed == 0) {
            System.out.println(">> STATUS: GESAMTES KERN-FRAMEWORK VOLL FUNKTIONSFAEHIG UND STABIL! <<");
        } else {
            System.err.println(">> STATUS: KRITISCHE FEHLER IM KERN-FRAMEWORK ENTDECKT! <<");
        }
    }

    private static void recordSuccess(String name, String detail) {
        testsPassed++;
        System.out.println("[BESTANDEN] " + name + " -> " + detail);
    }

    private static void recordFailure(String name, String detail) {
        testsFailed++;
        System.err.println("[FEHLGESCHLAGEN] " + name + " -> " + detail);
    }

    private static void test01_SuitEnumProperties() {
        Suit[] suits = Suit.values();
        if (suits.length == 4 && suits[0].getSymbol().equals("♣")) recordSuccess("Test 01", "Suit Enums korrekt.");
        else recordFailure("Test 01", "Suit Enum Fehler.");
    }

    private static void test02_RankEnumProperties() {
        if (Rank.values().length == 13 && Rank.ASS.getDefaultValue() == 11) recordSuccess("Test 02", "Rank Enums korrekt.");
        else recordFailure("Test 02", "Rank Enum Fehler.");
    }

    private static void test03_CardImmutabilityAndEquality() {
        Card c1 = new Card(Suit.HERZ, Rank.ASS);
        Card c2 = new Card(Suit.HERZ, Rank.ASS);
        if (c1.equals(c2) && c1.hashCode() == c2.hashCode()) recordSuccess("Test 03", "Equals & HashCode konsistent.");
        else recordFailure("Test 03", "Equals Vertrag verletzt.");
    }

   private static void test04_CardNullProtection() {
        try {
            @SuppressWarnings("unused")
            Card invalidCard = new Card(null, Rank.KOENIG);
            recordFailure("Test 04", "Keine Exception geworfen.");
        } catch (InvalidCardException e) {
            recordSuccess("Test 04", "Null-Schutz aktiv.");
        }
    }

    private static void test05_DeckInitialization52Cards() {
        Deck d = new Deck();
        d.initializeStandard52Deck();
        if (d.remainingCards() == 52) recordSuccess("Test 05", "52-Karten-Deck vollständig.");
        else recordFailure("Test 05", "Deckgröße fehlerhaft.");
    }

    private static void test06_DeckInitializationSkat32Cards() {
        Deck d = new Deck();
        d.initializeSkat32Deck();
        if (d.remainingCards() == 32) recordSuccess("Test 06", "32-Karten Skat-Deck initialisiert.");
        else recordFailure("Test 06", "Skatdeck fehlerhaft.");
    }

    private static void test07_FisherYatesShuffleIntegrity() {
        Deck d1 = new Deck(new Random(42));
        Deck d2 = new Deck(new Random(42));
        d1.initializeStandard52Deck();
        d2.initializeStandard52Deck();
        d1.shuffleFisherYates();
        boolean changed = !d1.getCardsSnapshot().get(0).equals(d2.getCardsSnapshot().get(0));
        if (changed && d1.remainingCards() == 52) recordSuccess("Test 07", "Fisher-Yates erfolgreich gemischt.");
        else recordFailure("Test 07", "Mischalgorithmus inkorrekt.");
    }

    private static void test08_DeckCutMechanism() {
        Deck d = new Deck();
        d.initializeStandard52Deck();
        Card top = d.getCardsSnapshot().get(0);
        d.cutAt(10);
        if (d.getCardsSnapshot().get(42).equals(top)) recordSuccess("Test 08", "Deck-Abheben erfolgreich.");
        else recordFailure("Test 08", "Abhebelogik falsch.");
    }

    private static void test09_DeckDrawSingleAndEmptyException() {
        Deck d = new Deck();
        try {
            d.drawCard();
            recordFailure("Test 09", "Keine Exception bei leerem Deck.");
        } catch (EmptyDeckException e) {
            recordSuccess("Test 09", "EmptyDeckException abgefangen.");
        }
    }

    private static void test10_DeckDrawMultipleCards() {
        Deck d = new Deck();
        d.initializeStandard52Deck();
        try {
            List<Card> drawn = d.drawMultiple(5);
            if (drawn.size() == 5 && d.remainingCards() == 47) recordSuccess("Test 10", "Mehrfachziehung verifiziert.");
            else recordFailure("Test 10", "Ziehfehler.");
        } catch (EmptyDeckException e) {
            recordFailure("Test 10", e.getMessage());
        }
    }

    private static void test11_DeckDealHandsEqually() {
        Deck d = new Deck();
        d.initializeStandard52Deck();
        try {
            List<Hand> hands = d.dealHands(4, 5);
            if (hands.size() == 4 && hands.get(0).size() == 5 && d.remainingCards() == 32) recordSuccess("Test 11", "Austeilen erfolgreich.");
            else recordFailure("Test 11", "Austeilfehler.");
        } catch (EmptyDeckException e) {
            recordFailure("Test 11", e.getMessage());
        }
    }

    private static void test12_HandNaturalSorting() {
        Hand h = new Hand();
        h.addCard(new Card(Suit.HERZ, Rank.KOENIG));
        h.addCard(new Card(Suit.PIK, Rank.ZWEI));
        h.sortByRank();
        if (h.getCard(0).getRank() == Rank.ZWEI) recordSuccess("Test 12", "Comparable-Sortierung erfolgreich.");
        else recordFailure("Test 12", "Sortierung falsch.");
    }

    private static void test13_HandCustomComparatorSorting() {
        Hand h = new Hand();
        h.addCard(new Card(Suit.HERZ, Rank.SIEBEN));
        h.addCard(new Card(Suit.HERZ, Rank.ASS));
        h.sortWithComparator(CardComparators.BY_RANK_DESCENDING);
        if (h.getCard(0).getRank() == Rank.ASS) recordSuccess("Test 13", "Comparator-Sortierung erfolgreich.");
        else recordFailure("Test 13", "Comparator fehlerhaft.");
    }

    private static void test14_HandBlackjackDynamicAceCalculation() {
        Hand h = new Hand();
        h.addCard(new Card(Suit.HERZ, Rank.ASS));
        h.addCard(new Card(Suit.PIK, Rank.NEUN));
        h.addCard(new Card(Suit.KARO, Rank.FUENF));
        if (h.calculateBlackjackValue() == 15) recordSuccess("Test 14", "Dynamische Ass-Berechnung (Blackjack) verifiziert.");
        else recordFailure("Test 14", "Blackjack-Wertberechnung weicht ab.");
    }

    private static void test15_HandFilterAndSearchMethods() {
        Hand h = new Hand();
        h.addCard(new Card(Suit.HERZ, Rank.ASS));
        if (h.hasSuit(Suit.HERZ) && !h.hasSuit(Suit.PIK)) recordSuccess("Test 15", "Suchfilter fehlerfrei.");
        else recordFailure("Test 15", "Suchmethode liefert falsches Ergebnis.");
    }
}

