package src;
/**
 * Repräsentiert die Rangwerte einer Spielkarte vom 2er-Wert bis zum Ass.
 * 
 * Jeder Rang hält einen Standard-Zahlenwert vor, der für Spiele wie Blackjack
 * oder für Punktabgleiche als Basispunktzahl fungiert.
 */
public enum Rank {
    ZWEI("Zwei", "2", 2),
    DREI("Drei", "3", 3),
    VIER("Vier", "4", 4),
    FUENF("Fünf", "5", 5),
    SECHS("Sechs", "6", 6),
    SIEBEN("Sieben", "7", 7),
    ACHT("Acht", "8", 8),
    NEUN("Neun", "9", 9),
    ZEHN("Zehn", "10", 10),
    BUBE("Bube", "B", 10),
    DAME("Dame", "D", 10),
    KOENIG("König", "K", 10),
    ASS("Ass", "A", 11);

    private final String displayName;
    private final String shortName;
    private final int defaultValue;

    Rank(String displayName, String shortName, int defaultValue) {
        this.displayName = displayName;
        this.shortName = shortName;
        this.defaultValue = defaultValue;
    }

    public String getDisplayName() {
        return displayName;
    }

    public String getShortName() {
        return shortName;
    }

    public int getDefaultValue() {
        return defaultValue;
    }

    @Override
    public String toString() {
        return displayName;
    }
}
