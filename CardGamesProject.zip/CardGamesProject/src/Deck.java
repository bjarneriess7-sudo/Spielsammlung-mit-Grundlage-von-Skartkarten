package src;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

/**
 * Verwaltet einen dynamischen Stapel von Spielkarten mit umfassenden Kontroll-,
 * Misch- und Austeilfunktionen.
 */
public class Deck {

    private final List<Card> cards;
    private final Random random;

    public Deck() {
        this.cards = new ArrayList<>();
        this.random = new Random();
    }

    public Deck(Random random) {
        this.cards = new ArrayList<>();
        this.random = (random != null) ? random : new Random();
    }

    public void initializeStandard52Deck() {
        this.cards.clear();
        for (Suit suit : Suit.values()) {
            for (Rank rank : Rank.values()) {
                this.cards.add(new Card(suit, rank));
            }
        }
    }

    public void initializeSkat32Deck() {
        this.cards.clear();
        for (Suit suit : Suit.values()) {
            for (Rank rank : Rank.values()) {
                if (rank.ordinal() >= Rank.SIEBEN.ordinal()) {
                    this.cards.add(new Card(suit, rank));
                }
            }
        }
    }

    public void shuffleFisherYates() {
        for (int i = this.cards.size() - 1; i > 0; i--) {
            int j = this.random.nextInt(i + 1);
            Card temp = this.cards.get(i);
            this.cards.set(i, this.cards.get(j));
            this.cards.set(j, temp);
        }
    }

    public void cutAt(int cutPoint) {
        if (cutPoint <= 0 || cutPoint >= this.cards.size()) {
            throw new IllegalArgumentException("Ungültiger Abhebepunkt.");
        }
        List<Card> topPart = new ArrayList<>(this.cards.subList(0, cutPoint));
        List<Card> bottomPart = new ArrayList<>(this.cards.subList(cutPoint, this.cards.size()));

        this.cards.clear();
        this.cards.addAll(bottomPart);
        this.cards.addAll(topPart);
    }

    public Card drawCard() throws EmptyDeckException {
        if (this.cards.isEmpty()) {
            throw new EmptyDeckException("Ziehversuch auf leerem Kartendeck fehlgeschlagen.");
        }
        return this.cards.remove(this.cards.size() - 1);
    }

    public List<Card> drawMultiple(int count) throws EmptyDeckException {
        if (count <= 0 || count > this.cards.size()) {
            throw new EmptyDeckException("Ungültige Kartenanzahl beim Ziehen.");
        }
        List<Card> drawn = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            drawn.add(drawCard());
        }
        return drawn;
    }

    public List<Hand> dealHands(int handCount, int cardsPerPlayer) throws EmptyDeckException {
        if (handCount <= 0 || cardsPerPlayer <= 0 || (handCount * cardsPerPlayer) > this.cards.size()) {
            throw new EmptyDeckException("Nicht genügend Karten zum Austeilen vorhanden.");
        }
        List<Hand> distributedHands = new ArrayList<>();
        for (int p = 0; p < handCount; p++) {
            distributedHands.add(new Hand());
        }
        for (int round = 0; round < cardsPerPlayer; round++) {
            for (int p = 0; p < handCount; p++) {
                distributedHands.get(p).addCard(drawCard());
            }
        }
        return distributedHands;
    }

    public int remainingCards() {
        return this.cards.size();
    }

    public boolean isEmpty() {
        return this.cards.isEmpty();
    }

    public List<Card> getCardsSnapshot() {
        return Collections.unmodifiableList(this.cards);
    }
}
