package src;
import java.io.Serializable;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * Modelliert ein Benutzerkonto mit SHA-256 Passwort-Hashing.
 */
public class UserAccount implements Serializable {
    private static final long serialVersionUID = 1L;

    private final String username;
    private final String passwordHash;
    private int totalScore;
    private int gamesPlayed;

    public UserAccount(String username, String plainPassword) {
        if (username == null || username.trim().isEmpty() || plainPassword == null || plainPassword.length() < 4) {
            throw new IllegalArgumentException("Ungültige Kontodaten angegeben.");
        }
        this.username = username.trim();
        this.passwordHash = hashPassword(plainPassword);
        this.totalScore = 0;
        this.gamesPlayed = 0;
    }

    public UserAccount(String username, String passwordHash, int totalScore, int gamesPlayed) {
        this.username = username;
        this.passwordHash = passwordHash;
        this.totalScore = totalScore;
        this.gamesPlayed = gamesPlayed;
    }

    public static String hashPassword(String password) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] encodedHash = digest.digest(password.getBytes(StandardCharsets.UTF_8));
            StringBuilder hexString = new StringBuilder();
            for (byte b : encodedHash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("SHA-256 nicht verfügbar.", e);
        }
    }

    public boolean verifyPassword(String plainPassword) {
        return this.passwordHash.equals(hashPassword(plainPassword));
    }

    public void addGameResult(int points) {
        this.totalScore += points;
        this.gamesPlayed++;
    }

    public String getUsername() { return username; }
    public String getPasswordHash() { return passwordHash; }
    public int getTotalScore() { return totalScore; }
    public int getGamesPlayed() { return gamesPlayed; }
}
