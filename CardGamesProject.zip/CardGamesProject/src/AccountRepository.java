package src;
import java.io.*;
import java.util.*;

/**
 * Persistiert Accounts und Spielstände in accounts.csv.
 */
public class AccountRepository {

    private final String filePath;
    private final Map<String, UserAccount> accounts;

    public AccountRepository(String filePath) {
        this.filePath = filePath;
        this.accounts = new HashMap<>();
        loadAccounts();
    }

    public synchronized boolean register(String username, String plainPassword) {
        if (accounts.containsKey(username.toLowerCase())) {
            return false;
        }
        UserAccount newAcc = new UserAccount(username, plainPassword);
        accounts.put(username.toLowerCase(), newAcc);
        saveAccounts();
        return true;
    }

    public synchronized UserAccount findByUsername(String username) {
        return accounts.get(username.toLowerCase());
    }

    public synchronized List<UserAccount> getLeaderboard() {
        List<UserAccount> list = new ArrayList<>(accounts.values());
        list.sort((a, b) -> Integer.compare(b.getTotalScore(), a.getTotalScore()));
        return list;
    }

    public synchronized void saveAccounts() {
        try (PrintWriter writer = new PrintWriter(new FileWriter(filePath))) {
            for (UserAccount acc : accounts.values()) {
                writer.println(acc.getUsername() + ";" + acc.getPasswordHash() + ";" + 
                               acc.getTotalScore() + ";" + acc.getGamesPlayed());
            }
        } catch (IOException e) {
            System.err.println("Fehler beim Speichern: " + e.getMessage());
        }
    }

    private synchronized void loadAccounts() {
        File file = new File(filePath);
        if (!file.exists()) return;

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(";");
                if (parts.length == 4) {
                    String user = parts[0];
                    String hash = parts[1];
                    int score = Integer.parseInt(parts[2]);
                    int played = Integer.parseInt(parts[3]);
                    accounts.put(user.toLowerCase(), new UserAccount(user, hash, score, played));
                }
            }
        } catch (Exception e) {
            System.err.println("Ladefehler: " + e.getMessage());
        }
    }
}
