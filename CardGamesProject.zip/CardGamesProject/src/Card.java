package src;
import java.util.Objects;

/**
 * Modelliert eine unveränderliche (immutable) Spielkarte, definiert durch Farbe und Rang.
 */
public class Card implements Comparable<Card> {

    private final Suit suit;
    private final Rank rank;

    public Card(Suit suit, Rank rank) {
        if (suit == null || rank == null) {
            throw new InvalidCardException("Kartenfarbe und Kartenrang dürfen nicht null sein.");
        }
        this.suit = suit;
        this.rank = rank;
    }

    public Suit getSuit() {
        return suit;
    }

    public Rank getRank() {
        return rank;
    }

    @Override
    public int compareTo(Card other) {
        if (other == null) {
            throw new NullPointerException("Vergleich mit einer Null-Referenz ist unzulässig.");
        }
        int rankDifference = Integer.compare(this.rank.ordinal(), other.rank.ordinal());
        if (rankDifference != 0) {
            return rankDifference;
        }
        return Integer.compare(this.suit.ordinal(), other.suit.ordinal());
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Card card = (Card) o;
        return suit == card.suit && rank == card.rank;
    }

    @Override
    public int hashCode() {
        return Objects.hash(suit, rank);
    }

    @Override
    public String toString() {
        return suit.getSymbol() + " " + rank.getDisplayName();
    }
}
